﻿using System;
using AppKit;

namespace MacConsoleExperiment
{
    class Program
    {
        static void Main(string[] args)
        {
            NSApplication.Init();
            Console.WriteLine("Hello World!");
        }
    }
}

